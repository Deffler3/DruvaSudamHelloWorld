﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HelloWorld;

namespace HelloWorldConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            GeneralUtility utility = new GeneralUtility();
            utility.sayHelloWorld();
            Console.Read();
        }
    }
}
