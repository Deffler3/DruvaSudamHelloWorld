﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PersistorLibrary;

namespace HelloWorld
{
    public class GeneralUtility
    {
       public void sayHelloWorld()
        {
            try {
                IOutputWriter writer = OutputWriterFactory.getOutputWriter();
                writer.write("HelloWorld!!");
            }
            catch(Exception e)
            {
                //
            }
        }
    }
}
