﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersistorLibrary
{
    class ConsoleWriter : IOutputWriter
    {
        public void write(string outputString)
        {
           Console.WriteLine(outputString);
        }
    }
}
