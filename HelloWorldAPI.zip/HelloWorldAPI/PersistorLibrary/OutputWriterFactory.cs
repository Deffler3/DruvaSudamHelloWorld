﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace PersistorLibrary
{
    public static class OutputWriterFactory
    {
        public static IOutputWriter getOutputWriter()
        {
            String outputWriterConfig =  ConfigurationSettings.AppSettings.Get("outputWriterType").ToString();
            switch (outputWriterConfig)
            {
                case "Console": return new ConsoleWriter();
                case "File": throw new Exception("File Writer not yet implemented");
                default: throw new Exception("Something went wrong");
            }

        }
    }
}
